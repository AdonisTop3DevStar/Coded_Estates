function AboutPage() {
    return (
      <div className="AboutPage">
        
      </div>
    );
  }
  
  export default AboutPage;
  