function SellPage() {
    return (
      <div className="SellPage">
        
      </div>
    );
  }
  
  export default SellPage;
  